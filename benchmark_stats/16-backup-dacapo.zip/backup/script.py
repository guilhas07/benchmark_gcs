import glob
import re
from collections import defaultdict
import json
import pprint


map = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
gcs = ["G1", "Parallel", "Serial"]
bench_names = set()
for file in glob.glob("*.json"):
    match = re.search(r"(\d+)m", file)
    assert match
    size = match[1]
    status = "error" if "error" in file else "success"
    gc = ""
    for i in gcs:
        if i in file:
            gc = i
            break

    match = re.search(f"DaCapo_(.*)_{gc}", file)
    assert match
    benchmark_name = match[1]
    bench_names.add(benchmark_name)
    map[int(size)][benchmark_name][status].append(gc)

for size in sorted(map.keys()):
    pprint.pprint(json.loads(f'{{"{size}":{json.dumps(map[size])}}}'))
# for gc in gcs:
#     for size in map:
#         if map[size][

# for size in map:
#     for name in bench_names:
#         error = f"Size: {size} Name: {name}\nGcs with error: "
#         success = "\n GCs with Success: "
#         for gc in gcs:
#             if name in map[size]["error"][gc]:
#                 error += f"{gc} "
#             elif name in map[size]["success"][gc]:
#                 success += f"{gc} "
#
#         print(error + success)
#         print()
